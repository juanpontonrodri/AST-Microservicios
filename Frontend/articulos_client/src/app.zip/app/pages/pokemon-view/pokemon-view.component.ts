import { Component, OnInit } from '@angular/core';
import { ObjectId } from 'mongoose';
import Pokemon from 'src/app/models/pokemon';
import { PokemonService } from 'src/app/pokemon.service';


@Component({
  selector: 'app-pokemon-view',
  templateUrl: './pokemon-view.component.html',
  styleUrls: ['./pokemon-view.component.css']
})
export class PokemonViewComponent implements OnInit{
 showformflag = false;
  showmodifyflag = false;
  showgetflag =false;
  rest= false;
  buttons=true;
  usuariorol!: string;
  success = false;
  failure = false;
  pokemons: Pokemon[] = [];
  pokemonSeleccionado!: Pokemon;
  url1: string = "https://assets.pokemon.com/assets/cms2/img/pokedex/full/";
  url2: string = ".png";
  finalurl: string = "726";
  
constructor(private pokemonService: PokemonService) {}
cancelmessage(){
  this.success=false;
  this.failure=false;
  this.rest=true;
}

showform(id : string) {
  this.pokemonService.getuserrol(id).subscribe(data => {
    this.usuariorol = data.toString();
   
    console.log(this.usuariorol);
    if (this.usuariorol === 'Administrador') {
      this.showformflag = true;
      this.rest=false;
      console.log("you have access");
      //this.bien3();
     
    } else {
      console.log("you better get out of here");
     // this.error();
    }
  });
  
}
cancelform() {
  this.showformflag = false;
  this.rest=true;
}
showget(id : string) {
  this.pokemonService.getuserrol(id).subscribe(data => {
    this.usuariorol = data.toString();
   
    console.log(this.usuariorol);
    if (this.usuariorol === 'Administrador') {
      this.showgetflag = true;
      this.rest=false;
      console.log("you have access");
      //this.bien3();
     
    } else {
      console.log("you better get out of here");
     // this.error();
    }
  });
  
}
cancelget() {
  this.showgetflag = false;
  this.rest=true;
}
modify(pokemon: Pokemon){
  this.pokemonSeleccionado = pokemon;
  this.showmodifyflag = true;
  this.rest=false;
}
cancelmodify() {
  this.showmodifyflag = false;
  this.rest=true;
}
tipoPokemon: string[] = [];
ngOnInit() {
  this.pokemonService.getPokemons()
  .subscribe((pokemons: any)=> this.pokemons = pokemons);
}
deletePokemon( pokemon : Pokemon) {
  this.pokemonService.deletePokemon(pokemon._id).subscribe(response => {
    this.rest=false;
    this.ngOnInit();
    
    // You can access status:
   if (response.status == 200){
    this.success=true;
   }
    else {
      this.failure=true;
    }
    
  });;
  
}
addPokemon(nombre: string ,numero: number, generacion: number ,region: string ,tipo:string ,evolucion: boolean,legendario : boolean,cantidad : number, precio: number) {
  this.showformflag = false;
  this.pokemonService.createPokemon(nombre,numero,generacion,region , tipo, evolucion, legendario,cantidad,precio)
  .subscribe(response => {
    this.rest=false;
    this.ngOnInit();
    
    // You can access status:
   if (response.status == 200){
    this.success=true;
   }
   else {
      this.failure=true;
    }
    
  } );
  
  
}

modifyPokemon(_id:string,nombre: string, numero: number, generacion: number, region: string, tipo:  string , evolucion: boolean, legendario: boolean, cantidad: number, precio: number){
  this.showmodifyflag = false;
  this.rest=true;
  this.pokemonService.putPokemon(_id,nombre,numero,generacion,region,tipo,evolucion,legendario,cantidad,precio)
  .subscribe(response => {
    this.rest=false;
    this.ngOnInit();
    
    // You can access status:
   if (response.status == 200){
    this.success=true;
   }
   else {
      this.failure=true;
    }
    
  });
}
getByName(_nombre: string) {
  this.pokemonService.getPokemonByName(_nombre).subscribe((pokemons: any)=>  this.pokemons = pokemons );
  this.showgetflag = false;
  this.rest=true;
}


getByID(id: string) {
 this.pokemonService.getPokemonByID(id).subscribe((pokemons: any)=>  this.pokemons = pokemons);
  this.showgetflag = false;
  this.rest=true;
}
checkrol(id: string){
  
  this.pokemonService.getuserrol(id).subscribe(data => {
    this.usuariorol = data.toString();
   
    console.log(this.usuariorol);
    if (this.usuariorol === 'Administrador') {
      this.rest=true;
      console.log("you have access");
      //this.bien3();
     
    } else {
      console.log("you better get out of here");
     // this.error();
    }
  });

}
 getBoolean(value: string){
  switch(value){
    case "true":
      return true;
     default:
        return false;
  }

}
}


