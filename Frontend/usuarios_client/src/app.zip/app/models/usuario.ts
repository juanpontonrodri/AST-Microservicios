
export default class Usuario{
    _id!:string 
    nombre!: string;
    rol!: string;
    

}
