export default class Compra{
    _id!: string
    idArticulo!: string;
    idCliente!: string;
    cantidad!: number; 
    nombre!: string;
    direccionEnvio!: string;
}