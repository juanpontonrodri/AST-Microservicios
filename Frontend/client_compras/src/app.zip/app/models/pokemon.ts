

export default class Pokemon{
    _id!:string 
    nombre!: string;
    numero!: number;
    generacion!: number;
    region!: string;
    tipo!:string;
    evolucion!: boolean;
    legendario!: boolean;
    cantidad!:number;
    precio!:number;
    

}